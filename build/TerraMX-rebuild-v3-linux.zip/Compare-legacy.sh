#!/usr/bin/env sh
cd -- "$(dirname -- "$0")"
exec ./TerraMX.x86_64 -- --legacy
