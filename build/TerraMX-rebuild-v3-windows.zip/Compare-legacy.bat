@echo off
cd /d "%~dp0"
start "Terra MX - preserved v2" "%~dp0TerraMX.exe" -- --legacy
